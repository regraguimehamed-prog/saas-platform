# ⚡ SaaS Platform

A **production-ready, full-stack SaaS application** built with FastAPI, PostgreSQL, Celery, and Streamlit. Engineered to Flippa-ready standards with async architecture, JWT auth, background task processing, AI integration, and multi-format report generation.

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Architecture](#architecture)
3. [Tech Stack](#tech-stack)
4. [Directory Structure](#directory-structure)
5. [Environment Variables](#environment-variables)
6. [Local Installation](#local-installation)
7. [Cloud Deployment](#cloud-deployment)
8. [API Reference](#api-reference)
9. [Running Tests](#running-tests)
10. [Dependencies](#dependencies)

---

## Project Overview

This platform provides:

- **Secure authentication** – JWT-based login/signup with bcrypt password hashing and token rotation.
- **AI-powered analysis** – Async OpenAI integration with retry logic and rate-limit handling.
- **Background task queue** – Celery + Redis for long-running jobs (AI analysis, report generation, email delivery).
- **Multi-format reports** – On-demand CSV, XLSX, and PDF export via Pandas and ReportLab.
- **Professional dashboard** – Dark-themed Streamlit UI with real-time task polling.
- **Structured logging** – Dual console + rotating file output for easy debugging and monitoring.

---

## Architecture

```
┌─────────────────┐    HTTP/REST    ┌──────────────────────┐
│  Streamlit UI   │ ─────────────▶ │   FastAPI Backend    │
│  (port 8501)    │ ◀───────────── │   (port 8000)        │
└─────────────────┘                └──────────┬───────────┘
                                              │
                          ┌───────────────────┼───────────────────┐
                          │                   │                   │
                   ┌──────▼──────┐   ┌────────▼──────┐  ┌───────▼──────┐
                   │ PostgreSQL  │   │ Redis (broker) │  │ Celery Worker│
                   │  (port 5432)│   │ (port 6379)    │  │              │
                   └─────────────┘   └────────────────┘  └──────────────┘
```

All backend operations use **async/await** (asyncpg + SQLAlchemy async). Celery workers are synchronous per task but run concurrently across processes.

---

## Tech Stack

| Layer        | Technology                              |
|--------------|-----------------------------------------|
| API          | FastAPI 0.115, Uvicorn, Pydantic v2     |
| Database     | PostgreSQL 16, SQLAlchemy 2 (async)     |
| Auth         | Passlib (bcrypt), python-jose (JWT)     |
| Task Queue   | Celery 5, Redis 7                       |
| AI           | OpenAI API (gpt-4o)                     |
| Reports      | Pandas, openpyxl, ReportLab             |
| Frontend     | Streamlit 1.41                          |
| Deployment   | Docker, docker-compose                  |

---

## Directory Structure

```
saas_platform/
├── app/
│   ├── api/
│   │   └── routes/
│   │       ├── auth.py          # Login, signup, token refresh, profile
│   │       └── reports.py       # Task submission, report generation
│   ├── core/
│   │   ├── config.py            # Settings (pydantic-settings + .env)
│   │   ├── logging.py           # Dual console/file logging setup
│   │   └── security.py          # Password hashing, JWT creation/decode
│   ├── db/
│   │   └── database.py          # Async engine, session factory, get_db
│   ├── models/
│   │   └── user.py              # ORM models: User, Task, Report
│   ├── schemas/
│   │   └── auth.py              # Pydantic request/response schemas
│   ├── services/
│   │   ├── ai_service.py        # OpenAI wrapper with retry logic
│   │   ├── report_service.py    # CSV / XLSX / PDF generator
│   │   └── user_service.py      # User CRUD + authentication
│   ├── tasks/
│   │   └── celery_app.py        # Celery app + task definitions
│   └── main.py                  # FastAPI app factory + lifespan
├── static/                      # Static assets (CSS, JS, images)
├── templates/                   # Jinja2 HTML templates (if needed)
├── docs/                        # Technical documentation
├── tests/
│   └── test_security.py         # Unit tests (security + reports)
├── logs/                        # Auto-created; gitignored
├── reports/                     # Generated report files; gitignored
├── streamlit_app.py             # Streamlit dashboard
├── setup_db.py                  # DB schema init + admin seed script
├── requirements.txt             # Pinned dependencies
├── Dockerfile                   # Multi-stage production image
├── docker-compose.yml           # Full-stack service orchestration
└── .env.example                 # Environment variable template
```

---

## Environment Variables

Copy `.env.example` to `.env` and fill in all values before starting.

| Variable                          | Description                                     | Required |
|-----------------------------------|-------------------------------------------------|----------|
| `SECRET_KEY`                      | Application secret (used for misc signing)      | ✅       |
| `DATABASE_URL`                    | Async PostgreSQL URL (`postgresql+asyncpg://…`) | ✅       |
| `JWT_SECRET_KEY`                  | JWT signing secret – keep long and random       | ✅       |
| `JWT_ACCESS_TOKEN_EXPIRE_MINUTES` | Access token lifetime (default: 30)             | –        |
| `JWT_REFRESH_TOKEN_EXPIRE_DAYS`   | Refresh token lifetime (default: 7)             | –        |
| `OPENAI_API_KEY`                  | OpenAI API key                                  | ✅       |
| `OPENAI_MODEL`                    | Model name (default: `gpt-4o`)                  | –        |
| `REDIS_URL`                       | Redis connection string                         | ✅       |
| `CELERY_BROKER_URL`               | Celery broker URL (usually same as Redis)       | ✅       |
| `CELERY_RESULT_BACKEND`           | Celery results backend URL                      | ✅       |
| `SMTP_HOST/PORT/USER/PASSWORD`    | SMTP email settings                             | –        |
| `LOG_LEVEL`                       | `DEBUG` / `INFO` / `WARNING` / `ERROR`          | –        |
| `API_BASE_URL`                    | Streamlit → API URL (default: localhost:8000)   | –        |

---

## Local Installation

### Prerequisites

- Python 3.12+
- PostgreSQL 14+
- Redis 7+
- (Optional) Docker + Docker Compose

### Step-by-step

```bash
# 1. Clone the repository
git clone https://github.com/yourname/saas-platform.git
cd saas-platform

# 2. Create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env with your DB credentials, JWT secret, OpenAI key, etc.

# 5. Initialise the database (creates tables + admin user)
python setup_db.py

# 6. Start services in separate terminals:

# Terminal A – FastAPI backend
uvicorn app.main:app --reload --port 8000

# Terminal B – Celery worker
celery -A app.tasks.celery_app worker --loglevel=info

# Terminal C – Streamlit UI
streamlit run streamlit_app.py

# 7. Open the dashboard
# Streamlit UI → http://localhost:8501
# FastAPI docs → http://localhost:8000/docs
# Flower (Celery) → http://localhost:5555  (start with: celery flower)
```

---

## Cloud Deployment

### Docker Compose (recommended)

```bash
# 1. Copy and fill in .env
cp .env.example .env

# 2. Build and start all services
docker compose up --build -d

# 3. Tail logs
docker compose logs -f api

# Services exposed:
#   FastAPI  → http://your-server:8000
#   Streamlit → http://your-server:8501
#   Flower   → http://your-server:5555
```

### AWS / DigitalOcean / Railway

1. Push your `.env`-free image to a container registry (ECR, Docker Hub, GHCR).
2. Set environment variables via the platform's secrets manager.
3. Deploy `api`, `ui`, `worker`, and `beat` as separate services.
4. Point `DATABASE_URL` at a managed PostgreSQL instance (RDS, DO Managed DB, Railway Postgres).
5. Point `REDIS_URL` at a managed Redis instance (ElastiCache, Upstash, Railway Redis).

### Reverse Proxy (Nginx)

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location /api/ { proxy_pass http://localhost:8000/; }
    location /     { proxy_pass http://localhost:8501/; }
}
```

---

## API Reference

Full interactive documentation is available at `http://localhost:8000/docs` (Swagger UI) when not in production mode.

| Method | Endpoint                        | Auth | Description                      |
|--------|---------------------------------|------|----------------------------------|
| POST   | `/auth/signup`                  | –    | Register a new user              |
| POST   | `/auth/login`                   | –    | Login, receive JWT pair          |
| POST   | `/auth/refresh`                 | –    | Rotate tokens                    |
| GET    | `/auth/me`                      | ✅   | Get current user profile         |
| PATCH  | `/auth/me`                      | ✅   | Update profile / password        |
| POST   | `/api/tasks/ai-analysis`        | ✅   | Submit AI analysis task          |
| GET    | `/api/tasks/{id}`               | ✅   | Poll task status                 |
| POST   | `/api/reports`                  | ✅   | Request report generation        |
| GET    | `/api/reports/{id}/download`    | ✅   | Download generated report        |
| GET    | `/health`                       | –    | Service health check             |

---

## Running Tests

```bash
# Run all tests with coverage report
pytest tests/ -v --cov=app --cov-report=term-missing

# Run a specific test file
pytest tests/test_security.py -v
```

---

## Dependencies

See `requirements.txt` for the complete pinned list. Key packages:

| Package              | Version  | Purpose                        |
|----------------------|----------|--------------------------------|
| `fastapi`            | 0.115.6  | Web framework                  |
| `sqlalchemy`         | 2.0.36   | ORM (async)                    |
| `asyncpg`            | 0.30.0   | PostgreSQL async driver        |
| `pydantic`           | 2.10.4   | Data validation                |
| `passlib[bcrypt]`    | 1.7.4    | Password hashing               |
| `python-jose`        | 3.3.0    | JWT                            |
| `celery`             | 5.4.0    | Task queue                     |
| `redis`              | 5.2.1    | Broker / result backend        |
| `httpx`              | 0.28.1   | Async HTTP client              |
| `pandas`             | 2.2.3    | Data processing / CSV / XLSX   |
| `reportlab`          | 4.2.5    | PDF generation                 |
| `streamlit`          | 1.41.1   | Dashboard UI                   |
| `python-dotenv`      | 1.0.1    | .env file loading              |

---

## License

MIT © 2025 Your Name. Commercial use permitted.
