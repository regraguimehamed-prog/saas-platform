"""
setup_db.py
-----------
One-shot script to initialise the PostgreSQL schema.

Run once after deployment:
    python setup_db.py

What it does:
  1. Loads configuration from .env.
  2. Imports all ORM models so SQLAlchemy is aware of them.
  3. Creates all tables that do not yet exist (idempotent).
  4. Optionally seeds a superuser admin account.
"""

from __future__ import annotations

import asyncio
import os
import sys

# ---------------------------------------------------------------------------
# Ensure the project root is on sys.path when called directly
# ---------------------------------------------------------------------------

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


async def create_tables() -> None:
    """
    Create all SQLAlchemy-mapped tables in the configured PostgreSQL database.

    Uses ``Base.metadata.create_all`` which is safe to call multiple times –
    it only creates tables that do not yet exist.
    """
    from app.core.logging import get_logger, setup_logging
    from app.db.database import Base, engine

    # Import all models so their metadata is registered on Base
    import app.models.user  # noqa: F401

    setup_logging()
    logger = get_logger("setup_db")

    logger.info("Connecting to database …")
    async with engine.begin() as conn:
        logger.info("Creating tables …")
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Schema initialisation complete ✓")


async def seed_admin() -> None:
    """
    Create a default superuser if one does not already exist.

    Credentials are read from environment variables:
      ADMIN_EMAIL    (default: admin@example.com)
      ADMIN_PASSWORD (default: ChangeMe123!)

    In production, override these via your deployment environment.
    """
    from app.core.logging import get_logger
    from app.db.database import get_db_context
    from app.models.user import User
    from app.core.security import hash_password
    from sqlalchemy import select

    logger = get_logger("setup_db")

    admin_email = os.getenv("ADMIN_EMAIL", "admin@example.com")
    admin_password = os.getenv("ADMIN_PASSWORD", "ChangeMe123!")

    async with get_db_context() as db:
        result = await db.execute(select(User).where(User.email == admin_email))
        existing = result.scalar_one_or_none()

        if existing:
            logger.info("Admin user already exists: %s", admin_email)
            return

        admin = User(
            email=admin_email,
            username="Admin",
            hashed_password=hash_password(admin_password),
            is_active=True,
            is_superuser=True,
        )
        db.add(admin)
        logger.info("Superuser created: %s", admin_email)


async def main() -> None:
    """Orchestrate table creation and optional seeding."""
    await create_tables()
    await seed_admin()
    print("\n✅  Database setup complete.\n")


if __name__ == "__main__":
    asyncio.run(main())
