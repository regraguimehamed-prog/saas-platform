"""
streamlit_app.py
----------------
Dark-themed Streamlit dashboard for the SaaS platform.

Features:
  - Login / Signup forms with JWT session management.
  - AI Analysis submission and live polling.
  - Report generation and download.
  - User profile management.

Run:
    streamlit run streamlit_app.py --server.port 8501
"""

from __future__ import annotations

import time
from typing import Any

import requests
import streamlit as st

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

import os
from dotenv import load_dotenv

load_dotenv()
API_BASE = os.getenv("API_BASE_URL", "http://localhost:8000")

# ---------------------------------------------------------------------------
# Page config (must be first Streamlit call)
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title="SaaS Platform",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Custom CSS – dark, professional theme
# ---------------------------------------------------------------------------

st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

    /* ── Global ─────────────────────────────────────── */
    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }
    .stApp {
        background: #0F172A;
        color: #E2E8F0;
    }

    /* ── Sidebar ─────────────────────────────────────── */
    [data-testid="stSidebar"] {
        background: #1E293B !important;
        border-right: 1px solid #334155;
    }
    [data-testid="stSidebar"] .stMarkdown h1,
    [data-testid="stSidebar"] .stMarkdown h2,
    [data-testid="stSidebar"] .stMarkdown h3 {
        color: #F8FAFC;
    }

    /* ── Metric cards ─────────────────────────────────── */
    [data-testid="stMetric"] {
        background: #1E293B;
        border: 1px solid #334155;
        border-radius: 12px;
        padding: 1.2rem 1.5rem;
    }
    [data-testid="stMetricLabel"] { color: #94A3B8 !important; font-size: 0.8rem; }
    [data-testid="stMetricValue"] { color: #F1F5F9 !important; font-size: 1.8rem; font-weight: 700; }
    [data-testid="stMetricDelta"] { font-size: 0.8rem; }

    /* ── Buttons ─────────────────────────────────────── */
    .stButton > button {
        background: linear-gradient(135deg, #3B82F6, #6366F1);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 0.55rem 1.4rem;
        font-weight: 600;
        font-size: 0.9rem;
        transition: opacity 0.2s, transform 0.1s;
        cursor: pointer;
    }
    .stButton > button:hover { opacity: 0.88; transform: translateY(-1px); }
    .stButton > button:active { transform: translateY(0); }

    /* ── Inputs ─────────────────────────────────────── */
    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea,
    .stSelectbox > div > div > select {
        background: #1E293B !important;
        color: #F1F5F9 !important;
        border: 1px solid #334155 !important;
        border-radius: 8px !important;
    }
    .stTextInput > div > div > input:focus,
    .stTextArea > div > div > textarea:focus {
        border-color: #3B82F6 !important;
        box-shadow: 0 0 0 3px rgba(59,130,246,0.15) !important;
    }

    /* ── Cards ─────────────────────────────────────── */
    .card {
        background: #1E293B;
        border: 1px solid #334155;
        border-radius: 12px;
        padding: 1.5rem;
        margin-bottom: 1rem;
    }
    .card-header {
        font-size: 1rem;
        font-weight: 600;
        color: #F8FAFC;
        margin-bottom: 0.8rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    /* ── Status badges ─────────────────────────────── */
    .badge {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
    }
    .badge-success { background: #064E3B; color: #6EE7B7; }
    .badge-pending { background: #1E3A5F; color: #93C5FD; }
    .badge-error   { background: #4C0519; color: #FCA5A5; }

    /* ── Divider ─────────────────────────────────────── */
    hr { border-color: #334155; }

    /* ── Code / mono ─────────────────────────────────── */
    code { font-family: 'JetBrains Mono', monospace; }
    </style>
    """,
    unsafe_allow_html=True,
)


# ---------------------------------------------------------------------------
# Session state helpers
# ---------------------------------------------------------------------------

def _init_state() -> None:
    defaults = {
        "access_token": None,
        "refresh_token": None,
        "user": None,
        "page": "login",
    }
    for key, val in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = val


_init_state()


def _auth_headers() -> dict[str, str]:
    return {"Authorization": f"Bearer {st.session_state.access_token}"}


def _api(
    method: str,
    path: str,
    auth: bool = True,
    **kwargs,
) -> tuple[int, Any]:
    """
    Thin wrapper around ``requests`` for talking to the FastAPI backend.

    Args:
        method: HTTP verb (GET, POST, PATCH, …).
        path:   URL path relative to ``API_BASE``.
        auth:   If ``True``, attach the Bearer token header.
        **kwargs: Forwarded to ``requests.request``.

    Returns:
        Tuple of ``(status_code, response_body_dict_or_none)``.
    """
    headers = _auth_headers() if auth else {}
    headers.update(kwargs.pop("headers", {}))
    try:
        resp = requests.request(
            method,
            f"{API_BASE}{path}",
            headers=headers,
            timeout=30,
            **kwargs,
        )
        try:
            return resp.status_code, resp.json()
        except Exception:
            return resp.status_code, None
    except requests.ConnectionError:
        st.error("❌ Cannot connect to the API. Is the server running?")
        return 0, None


# ---------------------------------------------------------------------------
# Auth pages
# ---------------------------------------------------------------------------

def page_login() -> None:
    """Render the login form."""
    st.markdown(
        "<h1 style='text-align:center; color:#F8FAFC; margin-bottom:0.2rem;'>⚡ SaaS Platform</h1>",
        unsafe_allow_html=True,
    )
    st.markdown(
        "<p style='text-align:center; color:#94A3B8; margin-bottom:2rem;'>Sign in to your account</p>",
        unsafe_allow_html=True,
    )

    with st.form("login_form"):
        email = st.text_input("Email", placeholder="you@example.com")
        password = st.text_input("Password", type="password")
        col1, col2 = st.columns(2)
        submitted = col1.form_submit_button("Sign In", use_container_width=True)
        go_signup = col2.form_submit_button("Create Account", use_container_width=True)

    if go_signup:
        st.session_state.page = "signup"
        st.rerun()

    if submitted:
        if not email or not password:
            st.error("Please enter your email and password.")
            return
        code, data = _api("POST", "/auth/login", auth=False, json={"email": email, "password": password})
        if code == 200:
            st.session_state.access_token = data["access_token"]
            st.session_state.refresh_token = data["refresh_token"]
            _, me = _api("GET", "/auth/me")
            st.session_state.user = me
            st.session_state.page = "dashboard"
            st.rerun()
        else:
            st.error(f"Login failed: {(data or {}).get('detail', 'Unknown error')}")


def page_signup() -> None:
    """Render the signup form."""
    st.markdown(
        "<h1 style='text-align:center; color:#F8FAFC; margin-bottom:0.2rem;'>Create Account</h1>",
        unsafe_allow_html=True,
    )

    with st.form("signup_form"):
        username = st.text_input("Display name")
        email = st.text_input("Email", placeholder="you@example.com")
        password = st.text_input("Password (min 8 chars)", type="password")
        submitted = st.form_submit_button("Register", use_container_width=True)
        go_login = st.form_submit_button("Back to Login", use_container_width=True)

    if go_login:
        st.session_state.page = "login"
        st.rerun()

    if submitted:
        code, data = _api(
            "POST", "/auth/signup", auth=False,
            json={"email": email, "username": username, "password": password},
        )
        if code == 201:
            st.success("Account created! Please sign in.")
            time.sleep(1)
            st.session_state.page = "login"
            st.rerun()
        else:
            st.error(f"Registration failed: {(data or {}).get('detail', 'Unknown error')}")


# ---------------------------------------------------------------------------
# Dashboard pages
# ---------------------------------------------------------------------------

def _sidebar() -> str:
    """Render the sidebar navigation. Returns the selected page name."""
    user = st.session_state.user or {}
    st.sidebar.markdown(
        f"<div style='padding:1rem 0 0.5rem;'>"
        f"<p style='color:#94A3B8; font-size:0.75rem; margin:0;'>Signed in as</p>"
        f"<p style='color:#F8FAFC; font-weight:600; margin:0;'>{user.get('username','User')}</p>"
        f"<p style='color:#64748B; font-size:0.75rem;'>{user.get('email','')}</p>"
        f"</div>",
        unsafe_allow_html=True,
    )
    st.sidebar.divider()

    pages = {
        "📊  Dashboard": "dashboard",
        "🤖  AI Analysis": "ai",
        "📄  Reports": "reports",
        "👤  Profile": "profile",
    }
    selection = st.sidebar.radio("Navigation", list(pages.keys()), label_visibility="collapsed")

    st.sidebar.divider()
    if st.sidebar.button("🚪  Sign Out", use_container_width=True):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        _init_state()
        st.rerun()

    return pages[selection]


def page_dashboard() -> None:
    """Overview metrics and recent activity."""
    st.markdown("## 📊 Dashboard")

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Active Users", "1,284", "+12%")
    col2.metric("Tasks Queued", "47", "-3")
    col3.metric("Reports Generated", "318", "+8%")
    col4.metric("API Calls Today", "9,621", "+24%")

    st.divider()
    st.markdown("### Recent Activity")
    st.markdown(
        """
        <div class="card">
            <div class="card-header">🕐 Latest Events</div>
            <table style="width:100%; border-collapse:collapse; font-size:0.87rem; color:#CBD5E1;">
                <tr style="color:#64748B; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.05em;">
                    <th style="text-align:left; padding:6px 0; border-bottom:1px solid #334155;">Event</th>
                    <th style="text-align:left; padding:6px 0; border-bottom:1px solid #334155;">User</th>
                    <th style="text-align:left; padding:6px 0; border-bottom:1px solid #334155;">Time</th>
                    <th style="text-align:left; padding:6px 0; border-bottom:1px solid #334155;">Status</th>
                </tr>
                <tr><td style="padding:8px 0; border-bottom:1px solid #1E293B;">AI Analysis</td><td>alice@example.com</td><td>2 min ago</td><td><span class="badge badge-success">Success</span></td></tr>
                <tr><td style="padding:8px 0; border-bottom:1px solid #1E293B;">Report – PDF</td><td>bob@example.com</td><td>8 min ago</td><td><span class="badge badge-success">Success</span></td></tr>
                <tr><td style="padding:8px 0; border-bottom:1px solid #1E293B;">AI Analysis</td><td>carol@example.com</td><td>15 min ago</td><td><span class="badge badge-pending">Running</span></td></tr>
                <tr><td style="padding:8px 0; border-bottom:1px solid #1E293B;">Report – XLSX</td><td>dave@example.com</td><td>22 min ago</td><td><span class="badge badge-error">Failed</span></td></tr>
                <tr><td style="padding:8px 0;">Login</td><td>eve@example.com</td><td>31 min ago</td><td><span class="badge badge-success">Success</span></td></tr>
            </table>
        </div>
        """,
        unsafe_allow_html=True,
    )


def page_ai() -> None:
    """AI Analysis submission form and result display."""
    st.markdown("## 🤖 AI Analysis")
    st.markdown(
        "<p style='color:#94A3B8;'>Submit text for background AI analysis. "
        "Results are processed asynchronously via the Celery worker.</p>",
        unsafe_allow_html=True,
    )

    with st.form("ai_form"):
        task_type = st.selectbox(
            "Analysis type",
            ["Sentiment Analysis", "Key Topics", "Summarisation", "Named Entities", "Custom"],
        )
        text = st.text_area("Text to analyse", height=200, placeholder="Paste your content here …")
        submitted = st.form_submit_button("🚀  Submit Analysis")

    if submitted:
        if not text.strip():
            st.warning("Please enter some text to analyse.")
            return

        with st.spinner("Submitting task …"):
            code, data = _api(
                "POST", "/api/tasks/ai-analysis",
                json={
                    "name": task_type,
                    "payload": {"text": text, "task_type": task_type},
                },
            )

        if code == 202:
            task_id = data["id"]
            st.success(f"Task submitted! ID: `{task_id}`")

            # Poll for result
            with st.status("Waiting for AI result …", expanded=True) as status_widget:
                for _ in range(30):
                    time.sleep(3)
                    poll_code, poll_data = _api("GET", f"/api/tasks/{task_id}")
                    task_status = (poll_data or {}).get("status", "pending")
                    status_widget.write(f"Status: **{task_status}**")

                    if task_status == "success":
                        status_widget.update(label="✅ Analysis complete!", state="complete")
                        import json
                        result = json.loads(poll_data.get("result", "{}"))
                        st.json(result)
                        break
                    elif task_status == "failure":
                        status_widget.update(label="❌ Task failed", state="error")
                        st.error(poll_data.get("error", "Unknown error"))
                        break
                else:
                    status_widget.update(label="⏳ Still processing – check back later", state="running")
        else:
            st.error(f"Failed to submit task: {(data or {}).get('detail', 'Unknown error')}")


def page_reports() -> None:
    """Report generation and download interface."""
    st.markdown("## 📄 Reports")
    st.markdown(
        "<p style='color:#94A3B8;'>Generate and download data reports in CSV, XLSX, or PDF format.</p>",
        unsafe_allow_html=True,
    )

    with st.form("report_form"):
        col1, col2 = st.columns(2)
        title = col1.text_input("Report title", placeholder="Q2 Sales Summary")
        fmt = col2.selectbox("Format", ["csv", "xlsx", "pdf"])
        submitted = st.form_submit_button("📥  Generate Report")

    if submitted:
        if not title:
            st.warning("Please enter a report title.")
            return

        with st.spinner("Requesting report generation …"):
            code, data = _api(
                "POST", "/api/reports",
                json={"title": title, "format": fmt, "filters": {}},
            )

        if code == 202:
            report_id = data["id"]
            st.success(f"Report queued! ID: `{report_id}`")

            with st.spinner("Waiting for report to be ready …"):
                for _ in range(20):
                    time.sleep(3)
                    dl_code, _ = _api("GET", f"/api/reports/{report_id}/download")
                    if dl_code == 200:
                        st.success("✅ Report is ready!")
                        st.markdown(
                            f"[⬇️ Download {title}.{fmt}]({API_BASE}/api/reports/{report_id}/download)",
                            unsafe_allow_html=False,
                        )
                        break
                    elif dl_code == 202:
                        continue
                    else:
                        st.error("An error occurred while generating the report.")
                        break
        else:
            st.error(f"Failed: {(data or {}).get('detail', 'Unknown')}")


def page_profile() -> None:
    """User profile update form."""
    st.markdown("## 👤 Profile")
    user = st.session_state.user or {}

    st.markdown(
        f"""
        <div class="card">
            <div class="card-header">Account Information</div>
            <p style="color:#94A3B8; margin:0; font-size:0.85rem;">ID</p>
            <p style="color:#F1F5F9; font-family:'JetBrains Mono', monospace; font-size:0.85rem;">{user.get('id','—')}</p>
            <p style="color:#94A3B8; margin:0; font-size:0.85rem;">Email</p>
            <p style="color:#F1F5F9;">{user.get('email','—')}</p>
            <p style="color:#94A3B8; margin:0; font-size:0.85rem;">Member since</p>
            <p style="color:#F1F5F9;">{user.get('created_at','—')[:10]}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("### Update Profile")
    with st.form("profile_form"):
        new_username = st.text_input("New username", value=user.get("username", ""))
        new_password = st.text_input("New password (leave blank to keep current)", type="password")
        submitted = st.form_submit_button("💾  Save Changes")

    if submitted:
        payload = {}
        if new_username and new_username != user.get("username"):
            payload["username"] = new_username
        if new_password:
            payload["password"] = new_password

        if not payload:
            st.info("Nothing to update.")
            return

        code, data = _api("PATCH", "/auth/me", json=payload)
        if code == 200:
            st.session_state.user = data
            st.success("Profile updated!")
            st.rerun()
        else:
            st.error(f"Update failed: {(data or {}).get('detail', 'Unknown error')}")


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

def main() -> None:
    """Main entry point: route to the correct page based on session state."""
    if not st.session_state.access_token:
        # Unauthenticated flow
        if st.session_state.page == "signup":
            page_signup()
        else:
            page_login()
        return

    # Authenticated flow – show sidebar + selected page
    selected = _sidebar()

    page_map = {
        "dashboard": page_dashboard,
        "ai": page_ai,
        "reports": page_reports,
        "profile": page_profile,
    }
    page_fn = page_map.get(selected, page_dashboard)
    page_fn()


if __name__ == "__main__":
    main()
