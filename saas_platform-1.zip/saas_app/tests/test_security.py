"""
tests/test_security.py
----------------------
Unit tests for the security module (password hashing and JWT).

Run:
    pytest tests/ -v
"""

from __future__ import annotations

import time
import uuid
from datetime import timedelta

import pytest
from jose import JWTError


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _patch_settings(monkeypatch):
    """
    Patch settings so tests never require a real .env file.
    """
    monkeypatch.setenv("SECRET_KEY", "test-secret")
    monkeypatch.setenv("JWT_SECRET_KEY", "test-jwt-secret")
    monkeypatch.setenv("DATABASE_URL", "postgresql+asyncpg://user:pass@localhost/testdb")


# ---------------------------------------------------------------------------
# Password hashing
# ---------------------------------------------------------------------------

class TestPasswordHashing:
    """Tests for :func:`~app.core.security.hash_password` and
    :func:`~app.core.security.verify_password`."""

    def test_hash_is_not_plain(self):
        from app.core.security import hash_password
        plain = "SecureP@ss1"
        hashed = hash_password(plain)
        assert hashed != plain

    def test_verify_correct_password(self):
        from app.core.security import hash_password, verify_password
        plain = "SecureP@ss1"
        hashed = hash_password(plain)
        assert verify_password(plain, hashed) is True

    def test_verify_wrong_password(self):
        from app.core.security import hash_password, verify_password
        hashed = hash_password("CorrectPassword")
        assert verify_password("WrongPassword", hashed) is False

    def test_two_hashes_differ(self):
        """bcrypt generates unique salts each call."""
        from app.core.security import hash_password
        plain = "SamePassword"
        assert hash_password(plain) != hash_password(plain)


# ---------------------------------------------------------------------------
# JWT
# ---------------------------------------------------------------------------

class TestJWT:
    """Tests for :func:`~app.core.security.create_access_token` and
    :func:`~app.core.security.decode_token`."""

    def test_access_token_round_trip(self):
        from app.core.security import create_access_token, decode_token
        subject = str(uuid.uuid4())
        token = create_access_token(subject)
        payload = decode_token(token)
        assert payload["sub"] == subject
        assert payload["type"] == "access"

    def test_refresh_token_round_trip(self):
        from app.core.security import create_refresh_token, decode_token
        subject = str(uuid.uuid4())
        token = create_refresh_token(subject)
        payload = decode_token(token)
        assert payload["type"] == "refresh"

    def test_extra_claims_included(self):
        from app.core.security import create_access_token, decode_token
        token = create_access_token("user-1", extra={"role": "admin"})
        payload = decode_token(token)
        assert payload["role"] == "admin"

    def test_expired_token_raises(self):
        """A token with a past expiry should raise JWTError."""
        from jose import jwt
        from app.core.config import settings
        from datetime import datetime, timezone

        now = datetime.now(tz=timezone.utc)
        payload = {
            "sub": "user-1",
            "type": "access",
            "iat": now,
            "exp": now - timedelta(seconds=1),  # already expired
            "jti": str(uuid.uuid4()),
        }
        expired_token = jwt.encode(
            payload, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM
        )
        with pytest.raises(JWTError):
            from app.core.security import decode_token
            decode_token(expired_token)

    def test_tampered_token_raises(self):
        from app.core.security import create_access_token, decode_token
        token = create_access_token("user-1")
        tampered = token[:-5] + "XXXXX"
        with pytest.raises(JWTError):
            decode_token(tampered)


# ---------------------------------------------------------------------------
# Report Service
# ---------------------------------------------------------------------------

class TestReportService:
    """Tests for :class:`~app.services.report_service.ReportService`."""

    _SAMPLE = [
        {"name": "Alice", "score": 95, "grade": "A"},
        {"name": "Bob", "score": 78, "grade": "B"},
        {"name": "Carol", "score": 88, "grade": "B+"},
    ]

    def test_csv_generation(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "reports").mkdir()

        from app.services import report_service as rs
        rs._REPORTS_DIR = tmp_path / "reports"

        service = rs.ReportService(self._SAMPLE, "Test Report")
        path = service.generate("csv")

        assert path.exists()
        assert path.suffix == ".csv"
        content = path.read_text()
        assert "Alice" in content
        assert "score" in content

    def test_xlsx_generation(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "reports").mkdir()

        from app.services import report_service as rs
        rs._REPORTS_DIR = tmp_path / "reports"

        service = rs.ReportService(self._SAMPLE, "Test Report")
        path = service.generate("xlsx")

        assert path.exists()
        assert path.suffix == ".xlsx"

    def test_pdf_generation(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "reports").mkdir()

        from app.services import report_service as rs
        rs._REPORTS_DIR = tmp_path / "reports"

        service = rs.ReportService(self._SAMPLE, "Test Report")
        path = service.generate("pdf")

        assert path.exists()
        assert path.suffix == ".pdf"
        # Verify PDF magic bytes
        assert path.read_bytes()[:4] == b"%PDF"

    def test_invalid_format_raises(self):
        from app.services.report_service import ReportService
        service = ReportService(self._SAMPLE, "Test")
        with pytest.raises(ValueError, match="Unsupported format"):
            service.generate("docx")
