"""
app/models/user.py
------------------
SQLAlchemy ORM model for the ``users`` table.

Relationships
-------------
* One-to-many with ``Task`` (a user can have many tasks).
* One-to-many with ``Report`` (a user can generate many reports).
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


def _now() -> datetime:
    return datetime.now(tz=timezone.utc)


class User(Base):
    """
    Represents an application user.

    Attributes:
        id:            UUID primary key (auto-generated).
        email:         Unique email address used for login.
        username:      Display name.
        hashed_password: bcrypt hash – never store plain text.
        is_active:     Soft-disable accounts without deletion.
        is_superuser:  Grants admin privileges.
        created_at:    UTC timestamp of account creation.
        updated_at:    UTC timestamp of last modification.
    """

    __tablename__ = "users"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True
    )
    email: Mapped[str] = mapped_column(
        String(255), unique=True, nullable=False, index=True
    )
    username: Mapped[str] = mapped_column(String(100), nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_superuser: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_now, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_now, onupdate=_now, nullable=False
    )

    # Relationships
    tasks: Mapped[list["Task"]] = relationship(
        "Task", back_populates="owner", cascade="all, delete-orphan"
    )
    reports: Mapped[list["Report"]] = relationship(
        "Report", back_populates="owner", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:  # noqa: D105
        return f"<User id={self.id} email={self.email}>"


class Task(Base):
    """
    Represents a background processing task submitted by a user.

    Attributes:
        id:          UUID primary key.
        owner_id:    FK to the submitting user.
        celery_id:   Celery task ID for status polling.
        name:        Human-readable task name.
        status:      pending | running | success | failure.
        result:      JSON-serialisable result payload (stored as text).
        error:       Error message if the task failed.
        created_at:  Submission timestamp.
        finished_at: Completion timestamp.
    """

    __tablename__ = "tasks"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True
    )
    owner_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False, index=True
    )
    celery_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="pending"
    )
    result: Mapped[str | None] = mapped_column(Text, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_now, nullable=False
    )
    finished_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # Relationships
    owner: Mapped["User"] = relationship("User", back_populates="tasks")

    def __repr__(self) -> str:  # noqa: D105
        return f"<Task id={self.id} name={self.name} status={self.status}>"


class Report(Base):
    """
    Represents a generated data report.

    Attributes:
        id:          UUID primary key.
        owner_id:    FK to the requesting user.
        title:       Report title.
        format:      csv | xlsx | pdf.
        file_path:   Relative path to the generated file on disk.
        row_count:   Number of data rows in the report.
        created_at:  Generation timestamp.
    """

    __tablename__ = "reports"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True
    )
    owner_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    format: Mapped[str] = mapped_column(String(10), nullable=False)
    file_path: Mapped[str] = mapped_column(String(512), nullable=False)
    row_count: Mapped[int] = mapped_column(nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_now, nullable=False
    )

    # Relationships
    owner: Mapped["User"] = relationship("User", back_populates="reports")

    def __repr__(self) -> str:  # noqa: D105
        return f"<Report id={self.id} title={self.title} format={self.format}>"
