"""
app/core/logging.py
-------------------
Configures a structured, dual-output logging system.

Outputs:
  - Console  : coloured, human-readable
  - File     : logs/app.log (rotating, JSON-friendly for log aggregators)

Usage:
    from app.core.logging import get_logger
    logger = get_logger(__name__)
    logger.info("Server started", extra={"port": 8000})
"""

import logging
import logging.handlers
import os
import sys
from pathlib import Path

from app.core.config import settings

# ---------------------------------------------------------------------------
# Formatters
# ---------------------------------------------------------------------------

CONSOLE_FMT = (
    "%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d | %(message)s"
)
FILE_FMT = (
    "%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d | %(funcName)s | %(message)s"
)
DATE_FMT = "%Y-%m-%d %H:%M:%S"


class _ColourFormatter(logging.Formatter):
    """Add ANSI colour codes to console log records."""

    COLOURS = {
        logging.DEBUG: "\033[36m",     # Cyan
        logging.INFO: "\033[32m",      # Green
        logging.WARNING: "\033[33m",   # Yellow
        logging.ERROR: "\033[31m",     # Red
        logging.CRITICAL: "\033[41m",  # Red background
    }
    RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:  # noqa: D102
        colour = self.COLOURS.get(record.levelno, self.RESET)
        record.levelname = f"{colour}{record.levelname}{self.RESET}"
        return super().format(record)


# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------

def setup_logging() -> None:
    """
    Initialise the root logger with a console handler and a rotating file handler.

    Should be called once at application startup (e.g. inside ``lifespan``).
    Subsequent calls are idempotent – handlers are not added twice.
    """
    log_level = getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO)

    # Ensure log directory exists
    log_path = Path(settings.LOG_FILE)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    root = logging.getLogger()
    if root.handlers:
        # Already configured; skip
        return

    root.setLevel(log_level)

    # --- Console handler ---------------------------------------------------
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(log_level)
    console_handler.setFormatter(
        _ColourFormatter(fmt=CONSOLE_FMT, datefmt=DATE_FMT)
    )
    root.addHandler(console_handler)

    # --- Rotating file handler ---------------------------------------------
    file_handler = logging.handlers.RotatingFileHandler(
        filename=settings.LOG_FILE,
        maxBytes=10 * 1024 * 1024,  # 10 MB
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setLevel(log_level)
    file_handler.setFormatter(logging.Formatter(fmt=FILE_FMT, datefmt=DATE_FMT))
    root.addHandler(file_handler)

    # Silence noisy third-party loggers in production
    if settings.is_production:
        for noisy in ("uvicorn.access", "sqlalchemy.engine", "httpx"):
            logging.getLogger(noisy).setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """
    Return a named logger.

    Args:
        name: Typically ``__name__`` of the calling module.

    Returns:
        A configured :class:`logging.Logger` instance.
    """
    return logging.getLogger(name)
