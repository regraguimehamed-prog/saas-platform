"""
app/core/security.py
--------------------
Authentication helpers: password hashing (Argon2 via Passlib) and
JWT creation / verification.

All token secrets are pulled from ``settings`` – never hardcoded.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Password hashing
# ---------------------------------------------------------------------------

_pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto",
    bcrypt__rounds=12,
)


def hash_password(plain: str) -> str:
    """
    Hash a plain-text password using bcrypt.

    Args:
        plain: The raw password provided by the user.

    Returns:
        A bcrypt hash string safe to store in the database.
    """
    return _pwd_context.hash(plain)


def verify_password(plain: str, hashed: str) -> bool:
    """
    Verify a plain-text password against a stored bcrypt hash.

    Args:
        plain:  The raw password to verify.
        hashed: The stored bcrypt hash.

    Returns:
        ``True`` if the password matches, ``False`` otherwise.
    """
    return _pwd_context.verify(plain, hashed)


# ---------------------------------------------------------------------------
# JWT helpers
# ---------------------------------------------------------------------------

_ACCESS_EXPIRE = timedelta(minutes=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES)
_REFRESH_EXPIRE = timedelta(days=settings.JWT_REFRESH_TOKEN_EXPIRE_DAYS)


def _create_token(
    subject: str | int,
    token_type: str,
    expires_delta: timedelta,
    extra_claims: dict[str, Any] | None = None,
) -> str:
    """
    Internal factory for signed JWTs.

    Args:
        subject:       The ``sub`` claim – usually a user ID.
        token_type:    ``"access"`` or ``"refresh"``.
        expires_delta: How long until the token expires.
        extra_claims:  Optional additional payload fields.

    Returns:
        A signed JWT string.
    """
    now = datetime.now(tz=timezone.utc)
    payload: dict[str, Any] = {
        "sub": str(subject),
        "type": token_type,
        "iat": now,
        "exp": now + expires_delta,
        "jti": str(uuid.uuid4()),  # unique token ID for revocation support
    }
    if extra_claims:
        payload.update(extra_claims)
    return jwt.encode(payload, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def create_access_token(subject: str | int, extra: dict | None = None) -> str:
    """
    Create a short-lived JWT access token.

    Args:
        subject: The user identifier to embed in ``sub``.
        extra:   Optional extra claims (e.g. ``{"role": "admin"}``).

    Returns:
        Signed JWT access token string.
    """
    return _create_token(subject, "access", _ACCESS_EXPIRE, extra)


def create_refresh_token(subject: str | int) -> str:
    """
    Create a long-lived JWT refresh token.

    Args:
        subject: The user identifier to embed in ``sub``.

    Returns:
        Signed JWT refresh token string.
    """
    return _create_token(subject, "refresh", _REFRESH_EXPIRE)


def decode_token(token: str) -> dict[str, Any]:
    """
    Decode and verify a JWT, returning the payload.

    Args:
        token: The raw JWT string.

    Returns:
        The decoded payload dictionary.

    Raises:
        :class:`jose.JWTError`: If the token is invalid or expired.
    """
    try:
        payload = jwt.decode(
            token,
            settings.JWT_SECRET_KEY,
            algorithms=[settings.JWT_ALGORITHM],
        )
        return payload
    except JWTError as exc:
        logger.warning("JWT decode failed: %s", exc)
        raise
