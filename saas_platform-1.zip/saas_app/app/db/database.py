"""
app/db/database.py
------------------
Async SQLAlchemy engine, session factory, and dependency injection helper.

Features
--------
* Async engine backed by asyncpg (PostgreSQL).
* Connection pooling configured for production workloads.
* ``get_db`` FastAPI dependency that yields a session and auto-commits
  on success or rolls back on exception.
* ``Base`` declarative base shared by all ORM models.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncGenerator

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,           # Log SQL only in debug mode
    pool_size=10,                  # Persistent connections kept open
    max_overflow=20,               # Extra connections allowed under load
    pool_pre_ping=True,            # Verify connections before use
    pool_recycle=3600,             # Recycle connections every hour
    connect_args={
        "server_settings": {
            "application_name": settings.APP_NAME,
        }
    },
)

# ---------------------------------------------------------------------------
# Session factory
# ---------------------------------------------------------------------------

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,   # Avoid lazy-load errors after commit
    autoflush=False,
    autocommit=False,
)


# ---------------------------------------------------------------------------
# Declarative base
# ---------------------------------------------------------------------------

class Base(DeclarativeBase):
    """
    Shared SQLAlchemy declarative base.

    All ORM models must inherit from this class so that
    ``Base.metadata.create_all`` picks them up automatically.
    """


# ---------------------------------------------------------------------------
# FastAPI dependency
# ---------------------------------------------------------------------------

async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI dependency that yields an async database session.

    Automatically commits on success and rolls back on any unhandled
    exception.  Use via ``Depends(get_db)`` in route handlers.

    Yields:
        An :class:`AsyncSession` bound to the shared engine.
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ---------------------------------------------------------------------------
# Context manager variant (for use outside FastAPI, e.g. scripts)
# ---------------------------------------------------------------------------

@asynccontextmanager
async def get_db_context() -> AsyncGenerator[AsyncSession, None]:
    """
    Async context manager variant of ``get_db`` for use in scripts
    and background tasks that run outside of a FastAPI request cycle.

    Example::

        async with get_db_context() as db:
            result = await db.execute(select(User))
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

async def check_db_connection() -> bool:
    """
    Verify the database is reachable.

    Returns:
        ``True`` if a test query succeeds, ``False`` otherwise.
    """
    from sqlalchemy import text

    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        logger.info("Database connection OK")
        return True
    except Exception as exc:
        logger.error("Database connection failed: %s", exc)
        return False
