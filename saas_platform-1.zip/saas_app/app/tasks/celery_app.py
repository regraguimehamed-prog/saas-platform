"""
app/tasks/celery_app.py
-----------------------
Celery application factory and task definitions.

Celery uses Redis as both the message broker and the result backend.
All configuration is pulled from ``settings`` – no hardcoded URLs.

Starting the worker:
    celery -A app.tasks.celery_app worker --loglevel=info --concurrency=4

Monitoring (Flower):
    celery -A app.tasks.celery_app flower --port=5555
"""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone

from celery import Celery
from celery.utils.log import get_task_logger

from app.core.config import settings

# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

celery_app = Celery(
    "saas_worker",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

celery_app.conf.update(
    # Serialisation
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    # Timezone
    timezone="UTC",
    enable_utc=True,
    # Reliability
    task_acks_late=True,           # Acknowledge only after task completes
    task_reject_on_worker_lost=True,
    worker_prefetch_multiplier=1,  # One task per worker at a time
    # Result TTL
    result_expires=86400,          # Keep results for 24 hours
    # Retry policy defaults
    task_default_retry_delay=60,
    task_max_retries=3,
    # Routing
    task_routes={
        "app.tasks.celery_app.run_ai_analysis": {"queue": "ai"},
        "app.tasks.celery_app.generate_report_task": {"queue": "reports"},
        "app.tasks.celery_app.send_email_task": {"queue": "emails"},
    },
)

logger = get_task_logger(__name__)


# ---------------------------------------------------------------------------
# Tasks
# ---------------------------------------------------------------------------

@celery_app.task(
    bind=True,
    name="app.tasks.celery_app.run_ai_analysis",
    max_retries=3,
    soft_time_limit=120,
    time_limit=150,
)
def run_ai_analysis(self, user_id: str, text: str, task_type: str) -> dict:
    """
    Background task: send text to OpenAI for analysis.

    This task is intentionally synchronous (Celery workers are not async).
    We use ``asyncio.run`` to call the async AI service.

    Args:
        user_id:   UUID string of the requesting user (for DB update).
        text:      The content to analyse.
        task_type: Analysis type string passed to :meth:`AIService.analyse_text`.

    Returns:
        A dict with ``status``, ``result``, and ``finished_at``.
    """
    import asyncio
    from app.services.ai_service import AIService

    logger.info("AI analysis started – user=%s type=%s", user_id, task_type)
    start = time.monotonic()

    try:
        service = AIService()
        result = asyncio.run(service.analyse_text(text, task_type))
        elapsed = time.monotonic() - start
        logger.info("AI analysis complete in %.2fs", elapsed)

        return {
            "status": "success",
            "result": result,
            "elapsed_seconds": round(elapsed, 2),
            "finished_at": datetime.now(tz=timezone.utc).isoformat(),
        }

    except Exception as exc:
        logger.error("AI analysis failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=30 * (self.request.retries + 1))


@celery_app.task(
    bind=True,
    name="app.tasks.celery_app.generate_report_task",
    max_retries=2,
    soft_time_limit=180,
    time_limit=200,
)
def generate_report_task(
    self,
    user_id: str,
    title: str,
    fmt: str,
    data: list[dict],
) -> dict:
    """
    Background task: generate a data report file.

    Args:
        user_id: UUID string of the requesting user.
        title:   Report title.
        fmt:     Output format – ``"csv"``, ``"xlsx"``, or ``"pdf"``.
        data:    List of row dicts to include in the report.

    Returns:
        A dict with ``status``, ``file_path``, and ``row_count``.
    """
    from app.services.report_service import ReportService

    logger.info("Report generation started – user=%s fmt=%s", user_id, fmt)

    try:
        service = ReportService(data=data, title=title)
        file_path = service.generate(fmt)

        return {
            "status": "success",
            "file_path": str(file_path),
            "row_count": len(data),
            "finished_at": datetime.now(tz=timezone.utc).isoformat(),
        }

    except Exception as exc:
        logger.error("Report generation failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=15)


@celery_app.task(
    bind=True,
    name="app.tasks.celery_app.send_email_task",
    max_retries=3,
)
def send_email_task(
    self,
    to_address: str,
    subject: str,
    body_html: str,
) -> dict:
    """
    Background task: send a transactional email via SMTP.

    Args:
        to_address: Recipient email address.
        subject:    Email subject line.
        body_html:  HTML email body.

    Returns:
        A dict with ``status`` and ``sent_at``.
    """
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText

    from app.core.config import settings as cfg

    logger.info("Sending email to %s", to_address)

    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = cfg.SMTP_FROM
        msg["To"] = to_address
        msg.attach(MIMEText(body_html, "html"))

        with smtplib.SMTP(cfg.SMTP_HOST, cfg.SMTP_PORT) as server:
            server.ehlo()
            server.starttls()
            server.login(cfg.SMTP_USER, cfg.SMTP_PASSWORD)
            server.sendmail(cfg.SMTP_FROM, [to_address], msg.as_string())

        logger.info("Email sent to %s", to_address)
        return {"status": "sent", "sent_at": datetime.now(tz=timezone.utc).isoformat()}

    except Exception as exc:
        logger.error("Failed to send email to %s: %s", to_address, exc)
        raise self.retry(exc=exc, countdown=60 * (self.request.retries + 1))
