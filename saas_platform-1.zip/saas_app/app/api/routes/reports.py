"""
app/api/routes/reports.py
-------------------------
Endpoints for submitting background tasks and generating/downloading reports.
"""

from __future__ import annotations

import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.routes.auth import get_current_user
from app.core.logging import get_logger
from app.db.database import get_db
from app.models.user import Report, Task
from app.schemas.auth import ReportCreate, ReportOut, TaskCreate, TaskOut
from app.tasks.celery_app import generate_report_task, run_ai_analysis

logger = get_logger(__name__)
router = APIRouter(prefix="/api", tags=["Tasks & Reports"])


# ---------------------------------------------------------------------------
# Background tasks
# ---------------------------------------------------------------------------

@router.post(
    "/tasks/ai-analysis",
    response_model=TaskOut,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Submit text for AI analysis (async)",
)
async def submit_ai_analysis(
    data: TaskCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """
    Enqueue an AI analysis task and return immediately.

    The client should poll ``GET /api/tasks/{task_id}`` for the result.

    Args:
        data:         Task parameters (name + payload with ``text`` and ``task_type``).
        db:           Async database session.
        current_user: Authenticated user from the Bearer token.

    Returns:
        A :class:`~app.schemas.auth.TaskOut` with ``status="pending"``.
    """
    text = data.payload.get("text", "")
    task_type = data.payload.get("task_type", "general analysis")

    # Persist task record
    db_task = Task(
        owner_id=current_user.id,
        name=data.name,
        status="pending",
    )
    db.add(db_task)
    await db.flush()

    # Enqueue Celery task
    celery_result = run_ai_analysis.apply_async(
        kwargs={
            "user_id": str(current_user.id),
            "text": text,
            "task_type": task_type,
        },
        task_id=str(db_task.id),
    )
    db_task.celery_id = celery_result.id
    db.add(db_task)

    logger.info("AI task enqueued: %s for user %s", db_task.id, current_user.id)
    return db_task


@router.get(
    "/tasks/{task_id}",
    response_model=TaskOut,
    summary="Poll a background task for its current status",
)
async def get_task(
    task_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """
    Return the current status of a background task.

    Also syncs the latest Celery state into the database record.

    Args:
        task_id:      UUID of the task to query.
        current_user: Must be the task owner.

    Returns:
        Updated :class:`~app.schemas.auth.TaskOut`.
    """
    from sqlalchemy import select
    from celery.result import AsyncResult

    result = await db.execute(
        select(Task).where(Task.id == task_id, Task.owner_id == current_user.id)
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Task not found")

    # Sync Celery state
    if task.celery_id and task.status in ("pending", "running"):
        celery_result = AsyncResult(task.celery_id)
        celery_state = celery_result.state
        if celery_state == "SUCCESS":
            import json
            task.status = "success"
            task.result = json.dumps(celery_result.result)
        elif celery_state == "FAILURE":
            task.status = "failure"
            task.error = str(celery_result.result)
        elif celery_state in ("STARTED", "RETRY"):
            task.status = "running"
        db.add(task)

    return task


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------

@router.post(
    "/reports",
    response_model=ReportOut,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Generate a downloadable report (async)",
)
async def create_report(
    data: ReportCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """
    Enqueue a report generation task and persist the metadata.

    The client can download the file when ready via ``GET /api/reports/{id}/download``.

    Args:
        data:         Report parameters (title, format, optional filters).
        db:           Async database session.
        current_user: Authenticated user.

    Returns:
        A :class:`~app.schemas.auth.ReportOut` with the report metadata.
    """
    # In production this data would come from a real query filtered by ``data.filters``
    sample_data = [
        {"id": i, "value": i * 10, "label": f"Row {i}"} for i in range(1, 51)
    ]

    # Persist report record (file path populated after task completes)
    db_report = Report(
        owner_id=current_user.id,
        title=data.title,
        format=data.format,
        file_path="pending",
        row_count=len(sample_data),
    )
    db.add(db_report)
    await db.flush()

    # Enqueue Celery task
    generate_report_task.apply_async(
        kwargs={
            "user_id": str(current_user.id),
            "title": data.title,
            "fmt": data.format,
            "data": sample_data,
        },
        task_id=str(db_report.id),
    )

    logger.info("Report task enqueued: %s", db_report.id)
    return db_report


@router.get(
    "/reports/{report_id}/download",
    summary="Download a generated report file",
)
async def download_report(
    report_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """
    Stream the generated report file back to the client.

    Args:
        report_id:    UUID of the report to download.
        current_user: Must be the report owner.

    Returns:
        A :class:`~fastapi.responses.FileResponse` with the correct media type.

    Raises:
        :class:`~fastapi.HTTPException` 404: If the report is not found.
        :class:`~fastapi.HTTPException` 202: If the report is still generating.
    """
    from sqlalchemy import select

    result = await db.execute(
        select(Report).where(
            Report.id == report_id, Report.owner_id == current_user.id
        )
    )
    report = result.scalar_one_or_none()
    if not report:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Report not found")

    if report.file_path == "pending":
        raise HTTPException(
            status_code=status.HTTP_202_ACCEPTED,
            detail="Report is still being generated. Try again shortly.",
        )

    file_path = Path(report.file_path)
    if not file_path.exists():
        raise HTTPException(
            status_code=status.HTTP_410_GONE,
            detail="Report file has expired or been deleted",
        )

    media_types = {
        "csv": "text/csv",
        "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "pdf": "application/pdf",
    }
    return FileResponse(
        path=str(file_path),
        media_type=media_types.get(report.format, "application/octet-stream"),
        filename=f"{report.title}.{report.format}",
    )
