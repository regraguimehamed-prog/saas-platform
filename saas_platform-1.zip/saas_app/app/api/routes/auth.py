"""
app/api/routes/auth.py
----------------------
Authentication endpoints: signup, login, token refresh, and profile.

All routes use ``async/await`` and depend on the shared database session
via ``get_db``.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import get_logger
from app.core.security import create_access_token, create_refresh_token, decode_token
from app.db.database import get_db
from app.schemas.auth import (
    MessageResponse,
    TokenPair,
    TokenRefresh,
    UserCreate,
    UserLogin,
    UserOut,
    UserUpdate,
)
from app.services.user_service import UserService

logger = get_logger(__name__)
router = APIRouter(prefix="/auth", tags=["Authentication"])
_bearer = HTTPBearer()


# ---------------------------------------------------------------------------
# Dependency: extract & verify the current user from the Authorization header
# ---------------------------------------------------------------------------

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer),
    db: AsyncSession = Depends(get_db),
):
    """
    FastAPI dependency that validates the Bearer token and returns the user.

    Args:
        credentials: Bearer token extracted from the Authorization header.
        db:          Async database session.

    Returns:
        The authenticated :class:`~app.models.user.User` ORM instance.

    Raises:
        :class:`~fastapi.HTTPException` 401: If the token is invalid or expired.
        :class:`~fastapi.HTTPException` 403: If the account is deactivated.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = decode_token(credentials.credentials)
        if payload.get("type") != "access":
            raise credentials_exception
        user_id: str = payload["sub"]
    except JWTError:
        raise credentials_exception

    import uuid
    service = UserService(db)
    user = await service.get_by_id(uuid.UUID(user_id))
    if not user:
        raise credentials_exception
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Account is deactivated"
        )
    return user


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.post(
    "/signup",
    response_model=UserOut,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new user",
)
async def signup(data: UserCreate, db: AsyncSession = Depends(get_db)):
    """
    Create a new user account.

    - Hashes the password before storage.
    - Returns the created user (without password hash).
    """
    service = UserService(db)
    try:
        user = await service.create_user(data)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc))
    logger.info("New user registered: %s", user.email)
    return user


@router.post(
    "/login",
    response_model=TokenPair,
    summary="Login and obtain JWT tokens",
)
async def login(data: UserLogin, db: AsyncSession = Depends(get_db)):
    """
    Validate credentials and return an access + refresh token pair.

    The access token expires in ``JWT_ACCESS_TOKEN_EXPIRE_MINUTES`` minutes.
    The refresh token expires in ``JWT_REFRESH_TOKEN_EXPIRE_DAYS`` days.
    """
    service = UserService(db)
    user = await service.authenticate(data.email, data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = create_access_token(str(user.id), extra={"email": user.email})
    refresh_token = create_refresh_token(str(user.id))
    logger.info("User logged in: %s", user.email)
    return TokenPair(access_token=access_token, refresh_token=refresh_token)


@router.post(
    "/refresh",
    response_model=TokenPair,
    summary="Refresh access token using a refresh token",
)
async def refresh_token(data: TokenRefresh, db: AsyncSession = Depends(get_db)):
    """
    Exchange a valid refresh token for a new access + refresh token pair.

    Implements token rotation – the old refresh token is implicitly invalidated
    when the client stores the new one.
    """
    import uuid

    invalid_exc = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired refresh token",
    )
    try:
        payload = decode_token(data.refresh_token)
        if payload.get("type") != "refresh":
            raise invalid_exc
        user_id = payload["sub"]
    except JWTError:
        raise invalid_exc

    service = UserService(db)
    user = await service.get_by_id(uuid.UUID(user_id))
    if not user or not user.is_active:
        raise invalid_exc

    access_token = create_access_token(str(user.id), extra={"email": user.email})
    new_refresh = create_refresh_token(str(user.id))
    return TokenPair(access_token=access_token, refresh_token=new_refresh)


@router.get(
    "/me",
    response_model=UserOut,
    summary="Get the current authenticated user's profile",
)
async def me(current_user=Depends(get_current_user)):
    """Return the profile of the currently authenticated user."""
    return current_user


@router.patch(
    "/me",
    response_model=UserOut,
    summary="Update the current user's profile",
)
async def update_me(
    data: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Update username and/or password for the authenticated user."""
    service = UserService(db)
    updated = await service.update_user(current_user, data)
    return updated
