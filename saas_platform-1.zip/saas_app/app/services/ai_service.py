"""
app/services/ai_service.py
--------------------------
Wrapper around the OpenAI API with retry logic, rate-limit handling,
and structured response parsing.

All API keys are read from ``settings`` – never hardcoded.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

import httpx

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_OPENAI_BASE = "https://api.openai.com/v1"
_MAX_RETRIES = 3
_RETRY_BACKOFF = 2.0   # seconds (doubles each retry)
_TIMEOUT = 60.0        # seconds per request


class RateLimitError(Exception):
    """Raised when the OpenAI API returns a 429 response."""


class AIServiceError(Exception):
    """Raised for unrecoverable AI API errors."""


class AIService:
    """
    Async client for the OpenAI Chat Completions API.

    Features:
    - Exponential back-off on 429 / 5xx responses.
    - Structured JSON mode support.
    - Token-usage logging for cost tracking.

    Args:
        api_key: Override the key from ``settings`` (useful in tests).
    """

    def __init__(self, api_key: str | None = None) -> None:
        self._api_key = api_key or settings.OPENAI_API_KEY
        self._model = settings.OPENAI_MODEL
        self._max_tokens = settings.OPENAI_MAX_TOKENS
        self._headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    async def chat(
        self,
        prompt: str,
        system: str = "You are a helpful assistant.",
        temperature: float = 0.7,
        json_mode: bool = False,
    ) -> str:
        """
        Send a single-turn chat completion request.

        Args:
            prompt:      The user message to send.
            system:      System-level instruction.
            temperature: Sampling temperature (0 = deterministic, 1 = creative).
            json_mode:   If ``True``, instructs the model to respond in JSON.

        Returns:
            The assistant's reply as a plain string.

        Raises:
            :class:`RateLimitError`: If rate-limited after all retries.
            :class:`AIServiceError`: For other unrecoverable errors.
        """
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ]
        body: dict[str, Any] = {
            "model": self._model,
            "messages": messages,
            "max_tokens": self._max_tokens,
            "temperature": temperature,
        }
        if json_mode:
            body["response_format"] = {"type": "json_object"}

        return await self._post_with_retry("/chat/completions", body)

    async def analyse_text(self, text: str, task: str) -> dict[str, Any]:
        """
        Run a structured analysis task on arbitrary text.

        Args:
            text: The content to analyse.
            task: Description of the analysis (e.g. ``"sentiment analysis"``).

        Returns:
            A dictionary parsed from the model's JSON response.
        """
        import json

        system = (
            "You are a data analysis expert. "
            "Always respond with valid JSON matching the requested schema."
        )
        prompt = f"Task: {task}\n\nContent:\n{text}\n\nRespond with JSON only."
        raw = await self.chat(prompt, system=system, json_mode=True, temperature=0.3)
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            logger.error("Failed to parse AI JSON response: %s", exc)
            return {"raw": raw, "parse_error": str(exc)}

    async def summarise(self, text: str, max_words: int = 150) -> str:
        """
        Produce a concise summary of the provided text.

        Args:
            text:      The text to summarise.
            max_words: Approximate maximum words for the summary.

        Returns:
            A summary string.
        """
        prompt = (
            f"Summarise the following text in approximately {max_words} words:\n\n{text}"
        )
        return await self.chat(prompt, temperature=0.4)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _post_with_retry(self, path: str, body: dict) -> str:
        """
        POST to the OpenAI API with exponential back-off on failure.

        Args:
            path: URL path relative to ``_OPENAI_BASE``.
            body: JSON request body.

        Returns:
            The assistant message content string.

        Raises:
            :class:`RateLimitError`: After exhausting retries on 429.
            :class:`AIServiceError`: On non-retryable errors.
        """
        url = f"{_OPENAI_BASE}{path}"
        delay = _RETRY_BACKOFF

        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            for attempt in range(1, _MAX_RETRIES + 1):
                try:
                    response = await client.post(url, json=body, headers=self._headers)

                    if response.status_code == 200:
                        data = response.json()
                        usage = data.get("usage", {})
                        logger.debug(
                            "OpenAI tokens used – prompt: %s, completion: %s",
                            usage.get("prompt_tokens"),
                            usage.get("completion_tokens"),
                        )
                        return data["choices"][0]["message"]["content"]

                    if response.status_code == 429:
                        retry_after = float(
                            response.headers.get("Retry-After", delay)
                        )
                        logger.warning(
                            "OpenAI rate limit hit (attempt %d/%d). "
                            "Retrying in %.1fs.",
                            attempt, _MAX_RETRIES, retry_after,
                        )
                        if attempt == _MAX_RETRIES:
                            raise RateLimitError(
                                "OpenAI rate limit exceeded after all retries"
                            )
                        await asyncio.sleep(retry_after)
                        delay *= 2
                        continue

                    if response.status_code >= 500:
                        logger.warning(
                            "OpenAI server error %s (attempt %d/%d). Retrying.",
                            response.status_code, attempt, _MAX_RETRIES,
                        )
                        if attempt == _MAX_RETRIES:
                            raise AIServiceError(
                                f"OpenAI returned {response.status_code} after all retries"
                            )
                        await asyncio.sleep(delay)
                        delay *= 2
                        continue

                    # 4xx client errors – do not retry
                    error_detail = response.json().get("error", {})
                    raise AIServiceError(
                        f"OpenAI API error {response.status_code}: "
                        f"{error_detail.get('message', response.text)}"
                    )

                except httpx.TimeoutException as exc:
                    logger.error("OpenAI request timed out (attempt %d): %s", attempt, exc)
                    if attempt == _MAX_RETRIES:
                        raise AIServiceError("OpenAI request timed out") from exc
                    await asyncio.sleep(delay)
                    delay *= 2

        raise AIServiceError("Unexpected exit from retry loop")


# ---------------------------------------------------------------------------
# Module-level singleton (lazy-initialised)
# ---------------------------------------------------------------------------

_ai_service: AIService | None = None


def get_ai_service() -> AIService:
    """
    Return a module-level singleton :class:`AIService`.

    Safe to call from multiple coroutines – instantiation is cheap and
    the underlying httpx client is created per-request.
    """
    global _ai_service
    if _ai_service is None:
        _ai_service = AIService()
    return _ai_service
