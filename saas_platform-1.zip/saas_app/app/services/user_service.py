"""
app/services/user_service.py
-----------------------------
Business-logic layer for user management.

Keeps route handlers thin – all database interaction happens here,
making it easy to unit-test without spinning up HTTP.
"""

from __future__ import annotations

import uuid
from typing import Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import get_logger
from app.core.security import hash_password, verify_password
from app.models.user import User
from app.schemas.auth import UserCreate, UserUpdate

logger = get_logger(__name__)


class UserService:
    """
    Provides CRUD operations for the :class:`~app.models.user.User` model.

    Args:
        db: An async SQLAlchemy session (injected via ``get_db``).
    """

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    # ------------------------------------------------------------------
    # Reads
    # ------------------------------------------------------------------

    async def get_by_id(self, user_id: uuid.UUID) -> User | None:
        """
        Fetch a user by primary key.

        Args:
            user_id: UUID of the target user.

        Returns:
            The :class:`User` instance, or ``None`` if not found.
        """
        result = await self.db.execute(select(User).where(User.id == user_id))
        return result.scalar_one_or_none()

    async def get_by_email(self, email: str) -> User | None:
        """
        Fetch a user by email address.

        Args:
            email: Email to look up (case-insensitive query).

        Returns:
            The :class:`User` instance, or ``None`` if not found.
        """
        result = await self.db.execute(
            select(User).where(User.email == email.lower())
        )
        return result.scalar_one_or_none()

    async def list_users(self, skip: int = 0, limit: int = 50) -> Sequence[User]:
        """
        Return a paginated list of all users.

        Args:
            skip:  Number of rows to skip (offset).
            limit: Maximum rows to return.

        Returns:
            A sequence of :class:`User` instances.
        """
        result = await self.db.execute(
            select(User).offset(skip).limit(limit).order_by(User.created_at.desc())
        )
        return result.scalars().all()

    # ------------------------------------------------------------------
    # Writes
    # ------------------------------------------------------------------

    async def create_user(self, data: UserCreate) -> User:
        """
        Register a new user.

        Hashes the plain-text password before persisting.

        Args:
            data: Validated :class:`~app.schemas.auth.UserCreate` payload.

        Returns:
            The newly created :class:`User` instance.

        Raises:
            ValueError: If the email address is already registered.
        """
        existing = await self.get_by_email(data.email)
        if existing:
            raise ValueError(f"Email '{data.email}' is already registered")

        user = User(
            email=data.email.lower(),
            username=data.username,
            hashed_password=hash_password(data.password),
        )
        self.db.add(user)
        await self.db.flush()  # Get the auto-generated id without full commit
        await self.db.refresh(user)
        logger.info("Created user %s (%s)", user.id, user.email)
        return user

    async def update_user(self, user: User, data: UserUpdate) -> User:
        """
        Update mutable user fields.

        Args:
            user: The :class:`User` ORM instance to modify.
            data: Fields to update; ``None`` values are ignored.

        Returns:
            The updated :class:`User` instance.
        """
        if data.username is not None:
            user.username = data.username
        if data.password is not None:
            user.hashed_password = hash_password(data.password)
        self.db.add(user)
        await self.db.flush()
        await self.db.refresh(user)
        return user

    async def deactivate_user(self, user: User) -> User:
        """
        Soft-delete a user by setting ``is_active = False``.

        Args:
            user: The :class:`User` to deactivate.

        Returns:
            The updated :class:`User` instance.
        """
        user.is_active = False
        self.db.add(user)
        await self.db.flush()
        logger.warning("Deactivated user %s", user.id)
        return user

    # ------------------------------------------------------------------
    # Auth helpers
    # ------------------------------------------------------------------

    async def authenticate(self, email: str, password: str) -> User | None:
        """
        Validate credentials and return the user if correct.

        Args:
            email:    The submitted email.
            password: The submitted plain-text password.

        Returns:
            The authenticated :class:`User`, or ``None`` on failure.
        """
        user = await self.get_by_email(email)
        if not user:
            logger.warning("Auth attempt for unknown email: %s", email)
            return None
        if not user.is_active:
            logger.warning("Auth attempt for inactive user: %s", email)
            return None
        if not verify_password(password, user.hashed_password):
            logger.warning("Invalid password for user: %s", email)
            return None
        return user
