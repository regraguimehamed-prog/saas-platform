"""
app/services/report_service.py
-------------------------------
Generates downloadable reports in CSV, XLSX, and PDF formats.

Libraries used:
  - pandas   : data wrangling and CSV/XLSX export
  - openpyxl : xlsx engine (used by pandas under the hood)
  - reportlab: PDF generation
"""

from __future__ import annotations

import io
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Output directory
# ---------------------------------------------------------------------------

_REPORTS_DIR = Path("reports")
_REPORTS_DIR.mkdir(exist_ok=True)


class ReportService:
    """
    Handles generation of CSV, XLSX, and PDF reports from raw data.

    Args:
        data:   List of dictionaries representing rows.
        title:  Human-readable report title (used in PDF headers).
    """

    def __init__(self, data: list[dict[str, Any]], title: str) -> None:
        self.df = pd.DataFrame(data)
        self.title = title

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def generate(self, fmt: str) -> Path:
        """
        Dispatch to the appropriate format generator.

        Args:
            fmt: One of ``"csv"``, ``"xlsx"``, or ``"pdf"``.

        Returns:
            :class:`~pathlib.Path` to the generated file.

        Raises:
            ValueError: If ``fmt`` is not recognised.
        """
        generators = {
            "csv": self._generate_csv,
            "xlsx": self._generate_xlsx,
            "pdf": self._generate_pdf,
        }
        if fmt not in generators:
            raise ValueError(f"Unsupported format '{fmt}'. Choose csv, xlsx, or pdf.")

        file_path = generators[fmt]()
        logger.info("Report generated: %s (%d rows)", file_path, len(self.df))
        return file_path

    # ------------------------------------------------------------------
    # Format generators
    # ------------------------------------------------------------------

    def _unique_path(self, ext: str) -> Path:
        """Build a unique file path inside the reports directory."""
        stamp = datetime.now(tz=timezone.utc).strftime("%Y%m%d_%H%M%S")
        filename = f"{stamp}_{uuid.uuid4().hex[:8]}.{ext}"
        return _REPORTS_DIR / filename

    def _generate_csv(self) -> Path:
        """
        Export the dataframe as a UTF-8 CSV file.

        Returns:
            Path to the generated ``.csv`` file.
        """
        path = self._unique_path("csv")
        self.df.to_csv(path, index=False, encoding="utf-8-sig")
        return path

    def _generate_xlsx(self) -> Path:
        """
        Export the dataframe as a formatted Excel workbook.

        Applies a header style and auto-fits column widths.

        Returns:
            Path to the generated ``.xlsx`` file.
        """
        path = self._unique_path("xlsx")

        with pd.ExcelWriter(path, engine="openpyxl") as writer:
            self.df.to_excel(writer, index=False, sheet_name="Report")
            workbook = writer.book
            worksheet = writer.sheets["Report"]

            # Style header row
            from openpyxl.styles import Font, PatternFill, Alignment

            header_fill = PatternFill(
                start_color="1E293B", end_color="1E293B", fill_type="solid"
            )
            header_font = Font(color="FFFFFF", bold=True)

            for cell in worksheet[1]:
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center")

            # Auto-fit column widths
            for col in worksheet.columns:
                max_len = max(
                    (len(str(cell.value or "")) for cell in col), default=10
                )
                worksheet.column_dimensions[col[0].column_letter].width = min(
                    max_len + 4, 50
                )

        return path

    def _generate_pdf(self) -> Path:
        """
        Export the dataframe as a styled PDF using ReportLab.

        Includes a title, generation timestamp, summary statistics,
        and a formatted data table.

        Returns:
            Path to the generated ``.pdf`` file.
        """
        path = self._unique_path("pdf")
        styles = getSampleStyleSheet()
        story = []

        # --- Title ---
        title_style = styles["Title"]
        story.append(Paragraph(self.title, title_style))
        story.append(Spacer(1, 0.4 * cm))

        # --- Metadata ---
        meta = f"Generated: {datetime.now(tz=timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}  |  Rows: {len(self.df)}"
        story.append(Paragraph(meta, styles["Normal"]))
        story.append(Spacer(1, 0.8 * cm))

        # --- Data table ---
        if not self.df.empty:
            headers = list(self.df.columns)
            rows = [headers] + self.df.astype(str).values.tolist()

            col_count = len(headers)
            page_width = A4[0] - 4 * cm  # usable width
            col_width = page_width / col_count

            table = Table(rows, colWidths=[col_width] * col_count, repeatRows=1)
            table.setStyle(
                TableStyle([
                    # Header row
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E293B")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 9),
                    ("ALIGN", (0, 0), (-1, 0), "CENTER"),
                    # Data rows
                    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                    ("FONTSIZE", (0, 1), (-1, -1), 8),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F1F5F9")]),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                    ("LEFTPADDING", (0, 0), (-1, -1), 6),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ])
            )
            story.append(table)
        else:
            story.append(Paragraph("No data available.", styles["Normal"]))

        doc = SimpleDocTemplate(
            str(path),
            pagesize=A4,
            leftMargin=2 * cm,
            rightMargin=2 * cm,
            topMargin=2 * cm,
            bottomMargin=2 * cm,
            title=self.title,
            author=settings.APP_NAME,
        )
        doc.build(story)
        return path
