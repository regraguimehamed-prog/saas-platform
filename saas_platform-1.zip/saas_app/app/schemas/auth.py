"""
app/schemas/auth.py
-------------------
Pydantic v2 schemas for authentication endpoints.

These are the data contracts for the API surface – not to be confused
with ORM models.  They enforce input validation and shape the JSON
responses returned to clients.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, EmailStr, Field, field_validator


# ---------------------------------------------------------------------------
# User schemas
# ---------------------------------------------------------------------------

class UserCreate(BaseModel):
    """Payload required to register a new user account."""

    email: EmailStr = Field(..., description="Unique email address")
    username: str = Field(..., min_length=3, max_length=100, description="Display name")
    password: str = Field(..., min_length=8, description="Plain-text password (hashed server-side)")

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        """Reject passwords that are entirely numeric."""
        if v.isdigit():
            raise ValueError("Password must contain at least one letter")
        return v


class UserLogin(BaseModel):
    """Credentials submitted at the /auth/login endpoint."""

    email: EmailStr
    password: str


class UserOut(BaseModel):
    """Safe user representation returned to clients (no password hash)."""

    id: uuid.UUID
    email: EmailStr
    username: str
    is_active: bool
    is_superuser: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class UserUpdate(BaseModel):
    """Fields that a user may update on their own profile."""

    username: str | None = Field(None, min_length=3, max_length=100)
    password: str | None = Field(None, min_length=8)


# ---------------------------------------------------------------------------
# Token schemas
# ---------------------------------------------------------------------------

class TokenPair(BaseModel):
    """Returned after a successful login or token refresh."""

    access_token: str
    refresh_token: str
    token_type: Literal["bearer"] = "bearer"


class TokenRefresh(BaseModel):
    """Payload required to refresh an access token."""

    refresh_token: str


class TokenPayload(BaseModel):
    """Decoded contents of a JWT (internal use only)."""

    sub: str
    type: str
    exp: int
    iat: int
    jti: str


# ---------------------------------------------------------------------------
# Task schemas
# ---------------------------------------------------------------------------

class TaskCreate(BaseModel):
    """Payload to enqueue a background task."""

    name: str = Field(..., description="Task type identifier, e.g. 'ai_analysis'")
    payload: dict = Field(default_factory=dict, description="Task-specific parameters")


class TaskOut(BaseModel):
    """Task representation returned to clients."""

    id: uuid.UUID
    celery_id: str | None
    name: str
    status: str
    result: str | None
    error: str | None
    created_at: datetime
    finished_at: datetime | None

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Report schemas
# ---------------------------------------------------------------------------

class ReportCreate(BaseModel):
    """Payload to request a data report."""

    title: str = Field(..., description="Human-readable report title")
    format: Literal["csv", "xlsx", "pdf"] = Field(
        "csv", description="Output format"
    )
    filters: dict = Field(
        default_factory=dict,
        description="Optional query filters applied before export",
    )


class ReportOut(BaseModel):
    """Report metadata returned to clients."""

    id: uuid.UUID
    title: str
    format: str
    row_count: int
    created_at: datetime

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Generic response wrappers
# ---------------------------------------------------------------------------

class MessageResponse(BaseModel):
    """Simple acknowledgement response."""

    message: str


class HealthResponse(BaseModel):
    """Health-check endpoint response."""

    status: Literal["ok", "degraded", "down"]
    database: bool
    version: str
