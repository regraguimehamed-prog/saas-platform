"""
app/main.py
-----------
FastAPI application factory with lifespan management.

Responsibilities:
  - Mount all API routers.
  - Setup logging and database at startup.
  - Configure CORS, security headers, and global exception handlers.
  - Expose the health-check endpoint.
"""

from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse

from app.api.routes.auth import router as auth_router
from app.api.routes.reports import router as reports_router
from app.core.config import settings
from app.core.logging import get_logger, setup_logging
from app.db.database import check_db_connection

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Lifespan (replaces deprecated on_event handlers)
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Execute startup and shutdown logic using the ASGI lifespan protocol.

    Startup:
      - Initialise the logging system.
      - Verify the database connection is healthy.

    Shutdown:
      - Log the shutdown event (add cleanup tasks here as needed).
    """
    # --- Startup ---
    setup_logging()
    logger.info("Starting %s [%s]", settings.APP_NAME, settings.APP_ENV)

    db_ok = await check_db_connection()
    if not db_ok and settings.is_production:
        raise RuntimeError("Database is unreachable – refusing to start in production")

    logger.info("Application ready. Listening on %s:%s", settings.APP_HOST, settings.APP_PORT)
    yield

    # --- Shutdown ---
    logger.info("Shutting down %s", settings.APP_NAME)


# ---------------------------------------------------------------------------
# Application factory
# ---------------------------------------------------------------------------

def create_app() -> FastAPI:
    """
    Build and configure the FastAPI application.

    Returns:
        A fully configured :class:`~fastapi.FastAPI` instance.
    """
    app = FastAPI(
        title=settings.APP_NAME,
        version="1.0.0",
        description=(
            "Production-grade SaaS API built with FastAPI, PostgreSQL, "
            "Celery, and OpenAI integration."
        ),
        docs_url="/docs" if not settings.is_production else None,
        redoc_url="/redoc" if not settings.is_production else None,
        lifespan=lifespan,
    )

    # -----------------------------------------------------------------------
    # Middleware
    # -----------------------------------------------------------------------

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"] if settings.DEBUG else [settings.API_BASE_URL],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    if settings.is_production:
        app.add_middleware(
            TrustedHostMiddleware,
            allowed_hosts=["yourdomain.com", "*.yourdomain.com"],
        )

    # -----------------------------------------------------------------------
    # Global exception handlers
    # -----------------------------------------------------------------------

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request: Request, exc: Exception):
        """Return a clean 500 response instead of leaking stack traces."""
        logger.exception("Unhandled exception for %s %s", request.method, request.url)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": "An internal server error occurred"},
        )

    # -----------------------------------------------------------------------
    # Routers
    # -----------------------------------------------------------------------

    app.include_router(auth_router)
    app.include_router(reports_router)

    # -----------------------------------------------------------------------
    # Health check
    # -----------------------------------------------------------------------

    @app.get("/health", tags=["System"], summary="Health check")
    async def health():
        """
        Return service health status.

        Checks:
          - API process is alive (always true if this endpoint responds).
          - Database connection is healthy.
        """
        db_ok = await check_db_connection()
        payload = {
            "status": "ok" if db_ok else "degraded",
            "database": db_ok,
            "version": "1.0.0",
            "environment": settings.APP_ENV,
        }
        http_status = status.HTTP_200_OK if db_ok else status.HTTP_503_SERVICE_UNAVAILABLE
        return JSONResponse(content=payload, status_code=http_status)

    return app


# ---------------------------------------------------------------------------
# ASGI entry point
# ---------------------------------------------------------------------------

app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host=settings.APP_HOST,
        port=settings.APP_PORT,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower(),
        access_log=True,
    )
